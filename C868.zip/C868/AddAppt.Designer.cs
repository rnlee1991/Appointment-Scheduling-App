﻿
namespace C969___PA.Screens
{
    partial class addAppt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.apptID = new System.Windows.Forms.Label();
            this.apptTB = new System.Windows.Forms.TextBox();
            this.custID = new System.Windows.Forms.Label();
            this.custTB = new System.Windows.Forms.TextBox();
            this.userID = new System.Windows.Forms.Label();
            this.userTB = new System.Windows.Forms.TextBox();
            this.title = new System.Windows.Forms.Label();
            this.titleTB = new System.Windows.Forms.TextBox();
            this.desc = new System.Windows.Forms.Label();
            this.descTB = new System.Windows.Forms.TextBox();
            this.location = new System.Windows.Forms.Label();
            this.locationTB = new System.Windows.Forms.TextBox();
            this.url = new System.Windows.Forms.Label();
            this.urlTB = new System.Windows.Forms.TextBox();
            this.startDatePicker = new System.Windows.Forms.DateTimePicker();
            this.startDate = new System.Windows.Forms.Label();
            this.endDatePicker = new System.Windows.Forms.DateTimePicker();
            this.endDate = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // apptID
            // 
            this.apptID.AutoSize = true;
            this.apptID.Location = new System.Drawing.Point(64, 39);
            this.apptID.Name = "apptID";
            this.apptID.Size = new System.Drawing.Size(80, 13);
            this.apptID.TabIndex = 0;
            this.apptID.Text = "Appointment ID";
            // 
            // apptTB
            // 
            this.apptTB.Location = new System.Drawing.Point(150, 32);
            this.apptTB.Name = "apptTB";
            this.apptTB.Size = new System.Drawing.Size(100, 20);
            this.apptTB.TabIndex = 1;
            // 
            // custID
            // 
            this.custID.AutoSize = true;
            this.custID.Location = new System.Drawing.Point(79, 73);
            this.custID.Name = "custID";
            this.custID.Size = new System.Drawing.Size(65, 13);
            this.custID.TabIndex = 2;
            this.custID.Text = "Customer ID";
            // 
            // custTB
            // 
            this.custTB.Location = new System.Drawing.Point(150, 66);
            this.custTB.Name = "custTB";
            this.custTB.Size = new System.Drawing.Size(100, 20);
            this.custTB.TabIndex = 3;
            // 
            // userID
            // 
            this.userID.AutoSize = true;
            this.userID.Location = new System.Drawing.Point(101, 110);
            this.userID.Name = "userID";
            this.userID.Size = new System.Drawing.Size(43, 13);
            this.userID.TabIndex = 4;
            this.userID.Text = "User ID";
            // 
            // userTB
            // 
            this.userTB.Location = new System.Drawing.Point(150, 103);
            this.userTB.Name = "userTB";
            this.userTB.Size = new System.Drawing.Size(100, 20);
            this.userTB.TabIndex = 5;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Location = new System.Drawing.Point(109, 143);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(27, 13);
            this.title.TabIndex = 6;
            this.title.Text = "Title";
            // 
            // titleTB
            // 
            this.titleTB.Location = new System.Drawing.Point(150, 136);
            this.titleTB.Name = "titleTB";
            this.titleTB.Size = new System.Drawing.Size(100, 20);
            this.titleTB.TabIndex = 7;
            // 
            // desc
            // 
            this.desc.AutoSize = true;
            this.desc.Location = new System.Drawing.Point(76, 175);
            this.desc.Name = "desc";
            this.desc.Size = new System.Drawing.Size(60, 13);
            this.desc.TabIndex = 8;
            this.desc.Text = "Description";
            // 
            // descTB
            // 
            this.descTB.Location = new System.Drawing.Point(150, 168);
            this.descTB.Name = "descTB";
            this.descTB.Size = new System.Drawing.Size(100, 20);
            this.descTB.TabIndex = 9;
            // 
            // location
            // 
            this.location.AutoSize = true;
            this.location.Location = new System.Drawing.Point(88, 207);
            this.location.Name = "location";
            this.location.Size = new System.Drawing.Size(48, 13);
            this.location.TabIndex = 10;
            this.location.Text = "Location";
            // 
            // locationTB
            // 
            this.locationTB.Location = new System.Drawing.Point(150, 200);
            this.locationTB.Name = "locationTB";
            this.locationTB.Size = new System.Drawing.Size(100, 20);
            this.locationTB.TabIndex = 11;
            // 
            // url
            // 
            this.url.AutoSize = true;
            this.url.Location = new System.Drawing.Point(109, 241);
            this.url.Name = "url";
            this.url.Size = new System.Drawing.Size(29, 13);
            this.url.TabIndex = 12;
            this.url.Text = "URL";
            // 
            // urlTB
            // 
            this.urlTB.Location = new System.Drawing.Point(150, 234);
            this.urlTB.Name = "urlTB";
            this.urlTB.Size = new System.Drawing.Size(100, 20);
            this.urlTB.TabIndex = 13;
            // 
            // startDatePicker
            // 
            this.startDatePicker.Location = new System.Drawing.Point(129, 275);
            this.startDatePicker.Name = "startDatePicker";
            this.startDatePicker.Size = new System.Drawing.Size(200, 20);
            this.startDatePicker.TabIndex = 14;
            // 
            // startDate
            // 
            this.startDate.AutoSize = true;
            this.startDate.Location = new System.Drawing.Point(68, 281);
            this.startDate.Name = "startDate";
            this.startDate.Size = new System.Drawing.Size(55, 13);
            this.startDate.TabIndex = 15;
            this.startDate.Text = "Start Date";
            // 
            // endDatePicker
            // 
            this.endDatePicker.Location = new System.Drawing.Point(129, 314);
            this.endDatePicker.Name = "endDatePicker";
            this.endDatePicker.Size = new System.Drawing.Size(200, 20);
            this.endDatePicker.TabIndex = 16;
            // 
            // endDate
            // 
            this.endDate.AutoSize = true;
            this.endDate.Location = new System.Drawing.Point(71, 320);
            this.endDate.Name = "endDate";
            this.endDate.Size = new System.Drawing.Size(52, 13);
            this.endDate.TabIndex = 17;
            this.endDate.Text = "End Date";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(48, 388);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 18;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(239, 388);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 19;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // addAppt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 472);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.endDatePicker);
            this.Controls.Add(this.startDate);
            this.Controls.Add(this.startDatePicker);
            this.Controls.Add(this.urlTB);
            this.Controls.Add(this.url);
            this.Controls.Add(this.locationTB);
            this.Controls.Add(this.location);
            this.Controls.Add(this.descTB);
            this.Controls.Add(this.desc);
            this.Controls.Add(this.titleTB);
            this.Controls.Add(this.title);
            this.Controls.Add(this.userTB);
            this.Controls.Add(this.userID);
            this.Controls.Add(this.custTB);
            this.Controls.Add(this.custID);
            this.Controls.Add(this.apptTB);
            this.Controls.Add(this.apptID);
            this.Name = "addAppt";
            this.Text = "Add Appointment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label apptID;
        private System.Windows.Forms.TextBox apptTB;
        private System.Windows.Forms.Label custID;
        private System.Windows.Forms.TextBox custTB;
        private System.Windows.Forms.Label userID;
        private System.Windows.Forms.TextBox userTB;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.TextBox titleTB;
        private System.Windows.Forms.Label desc;
        private System.Windows.Forms.TextBox descTB;
        private System.Windows.Forms.Label location;
        private System.Windows.Forms.TextBox locationTB;
        private System.Windows.Forms.Label url;
        private System.Windows.Forms.TextBox urlTB;
        private System.Windows.Forms.DateTimePicker startDatePicker;
        private System.Windows.Forms.Label startDate;
        private System.Windows.Forms.DateTimePicker endDatePicker;
        private System.Windows.Forms.Label endDate;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
    }
}