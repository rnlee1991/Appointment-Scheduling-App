﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C969___PA
{
    public partial class UserSchedule : Form
    {
        string connString = "server = wgudb.ucertify.com; database = U07xPr; uid = U07xPr; pwd = 53689162285;";
        public UserSchedule()
        {
            InitializeComponent();
            userCombo.SelectedItem = "test";
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                MySqlCommand cmd = new MySqlCommand();
                cmd.CommandText = "SELECT * from appointment WHERE createdBy = ' test ';";
                MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
                DataTable userSchedule = new DataTable();
                cmd.Connection = conn;
                conn.Open();
                adp.Fill(userSchedule);
                userSchduleReport.DataSource = userSchedule;
            }
        }


        private void homeButton_Click(object sender, EventArgs e)
        {
            MainScreen main = new MainScreen();
            this.Hide();
            main.Show();
        }


    }
}
