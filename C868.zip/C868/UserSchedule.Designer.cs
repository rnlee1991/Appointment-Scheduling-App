﻿
namespace C969___PA
{
    partial class UserSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userCombo = new System.Windows.Forms.ComboBox();
            this.reportButton = new System.Windows.Forms.Button();
            this.userSchduleReport = new System.Windows.Forms.DataGridView();
            this.homeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.userSchduleReport)).BeginInit();
            this.SuspendLayout();
            // 
            // userCombo
            // 
            this.userCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.userCombo.FormattingEnabled = true;
            this.userCombo.Items.AddRange(new object[] {
            "test"});
            this.userCombo.Location = new System.Drawing.Point(123, 43);
            this.userCombo.Name = "userCombo";
            this.userCombo.Size = new System.Drawing.Size(121, 21);
            this.userCombo.TabIndex = 0;
            // 
            // reportButton
            // 
            this.reportButton.Location = new System.Drawing.Point(147, 96);
            this.reportButton.Name = "reportButton";
            this.reportButton.Size = new System.Drawing.Size(75, 23);
            this.reportButton.TabIndex = 1;
            this.reportButton.Text = "Run Report";
            this.reportButton.UseVisualStyleBackColor = true;
            this.reportButton.Click += new System.EventHandler(this.reportButton_Click);
            // 
            // userSchduleReport
            // 
            this.userSchduleReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userSchduleReport.Location = new System.Drawing.Point(12, 143);
            this.userSchduleReport.Name = "userSchduleReport";
            this.userSchduleReport.Size = new System.Drawing.Size(340, 219);
            this.userSchduleReport.TabIndex = 2;
            // 
            // homeButton
            // 
            this.homeButton.Location = new System.Drawing.Point(107, 392);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(163, 23);
            this.homeButton.TabIndex = 3;
            this.homeButton.Text = "Return to Main Screen";
            this.homeButton.UseVisualStyleBackColor = true;
            this.homeButton.Click += new System.EventHandler(this.homeButton_Click);
            // 
            // UserSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 450);
            this.Controls.Add(this.homeButton);
            this.Controls.Add(this.userSchduleReport);
            this.Controls.Add(this.reportButton);
            this.Controls.Add(this.userCombo);
            this.Name = "UserSchedule";
            this.Text = "User\'s Schedule Report";
            ((System.ComponentModel.ISupportInitialize)(this.userSchduleReport)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox userCombo;
        private System.Windows.Forms.Button reportButton;
        private System.Windows.Forms.DataGridView userSchduleReport;
        private System.Windows.Forms.Button homeButton;
    }
}